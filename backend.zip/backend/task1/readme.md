```markdown
# User CRUD API

A simple FastAPI-based REST API for managing users in memory. Each user has:
- `id` (UUID)
- `name`
- `email`
- `age`

Supports Create, Read, Update, Delete operations.

---

## Requirements

- Python 3.8+
- pip

---

## Installation

1. Clone the repo (or copy the files) into a folder:
```

/project-root
│
├── main.py
├── models.py
└── requirements.txt

````

2. In that folder, create and activate a virtual environment (optional but recommended):
```bash
python3 -m venv .venv
source .venv/bin/activate      # macOS/Linux
.venv\Scripts\activate         # Windows
````

3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

   > **Note**: If you see
   >
   > ```
   > ImportError: email-validator is not installed
   > ```
   >
   > run:
   >
   > ```bash
   > pip install pydantic[email]
   > ```

---

## Running the Server

Start Uvicorn from the project root:

```bash
uvicorn main:app --reload
```

* The API will be available at `http://127.0.0.1:8000`.
* Open `http://127.0.0.1:8000/docs` in your browser for interactive documentation.

---

## API Endpoints

### Create a new user

```
POST /users
```

* **Request Body** (JSON):

  ```json
  {
    "name": "Alice",
    "email": "alice@example.com",
    "age": 30
  }
  ```
* **Success Response**: `201 Created`

  ```json
  {
    "id": "e8a1a07d-1b8f-4a21-9d5f-0f8b1ad2c4f7",
    "name": "Alice",
    "email": "alice@example.com",
    "age": 30
  }
  ```
* **Validation Errors**: `422 Unprocessable Entity`

---

### Get all users

```
GET /users
```

* **Response**: `200 OK`

  ```json
  [
    {
      "id": "e8a1a07d-1b8f-4a21-9d5f-0f8b1ad2c4f7",
      "name": "Alice",
      "email": "alice@example.com",
      "age": 30
    },
    {
      "id": "a3b2c1d4-5e6f-7a8b-9c0d-1e2f3a4b5c6d",
      "name": "Bob",
      "email": "bob@example.com",
      "age": 25
    }
  ]
  ```
* If no users exist, returns `[]`.

---

### Get a single user

```
GET /users/{user_id}
```

* **Path Parameter**: `user_id` (UUID)
* **Success Response**: `200 OK`

  ```json
  {
    "id": "e8a1a07d-1b8f-4a21-9d5f-0f8b1ad2c4f7",
    "name": "Alice",
    "email": "alice@example.com",
    "age": 30
  }
  ```
* **Error**: `404 Not Found`

  ```json
  {
    "detail": "User with id {user_id} not found."
  }
  ```
* **Invalid UUID**: `422 Unprocessable Entity`

---

### Update a user

```
PUT /users/{user_id}
```

* **Path Parameter**: `user_id` (UUID)
* **Request Body** (JSON):

  ```json
  {
    "name": "Alice Smith",
    "email": "alice.smith@example.com",
    "age": 31
  }
  ```
* **Success Response**: `200 OK`

  ```json
  {
    "id": "e8a1a07d-1b8f-4a21-9d5f-0f8b1ad2c4f7",
    "name": "Alice Smith",
    "email": "alice.smith@example.com",
    "age": 31
  }
  ```
* **Error (not found)**: `404 Not Found`
* **Validation Errors**: `422 Unprocessable Entity`

---

### Delete a user

```
DELETE /users/{user_id}
```

* **Path Parameter**: `user_id` (UUID)
* **Success Response**: `204 No Content`
* **Error**: `404 Not Found`

  ```json
  {
    "detail": "User with id {user_id} not found; cannot delete."
  }
  ```

---

## Troubleshooting

* **“ImportError: email-validator is not installed”**
  Pydantic’s `EmailStr` type requires the `email-validator` package. If you see that error:

  ```bash
  pip install pydantic[email]
  ```

* **Other 422 Errors**
  The API uses Pydantic for input validation.

  * Make sure `name` is a non-empty string.
  * Make sure `email` is valid (e.g., `user@example.com`).
  * Make sure `age` is an integer > 0 and ≤ 150.

* **Server Not Restarting on Changes**
  Run Uvicorn with `--reload`:

  ```bash
  uvicorn main:app --reload
  ```

---


