
from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from uuid import UUID


class UserBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)
    email: EmailStr
    age: int = Field(..., gt=0, le=150, description="Age must be a positive integer (<=150)")


class UserCreate(UserBase):
    """
    Inherit from UserBase.  Used for POST /users and PUT /users/{id}.
    """
    pass


class User(UserBase):
    id: UUID

    class Config:
        orm_mode = True
