# main.py

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from typing import List
from uuid import uuid4, UUID
from models import User, UserCreate

app = FastAPI(title="User CRUD API")

# Allow CORS (optional)—adjust origins as needed
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# In‐memory “database”
# Key: UUID of the user; Value: User instance (as a dict)
users_db: dict[UUID, User] = {}


@app.post(
    "/users",
    response_model=User,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new user",
)
def create_user(payload: UserCreate):
    """
    Create a new user.  
    - **name**: non‐empty string (1–50 chars)  
    - **email**: must be valid email format  
    - **age**: positive integer  

    Returns the newly created user with a generated UUID.
    """
    new_id = uuid4()
    user = User(id=new_id, **payload.dict())
    users_db[new_id] = user
    return user


@app.get(
    "/users",
    response_model=List[User],
    status_code=status.HTTP_200_OK,
    summary="Get all users",
)
def get_all_users():
    """
    Retrieve a list of all users.  
    Returns `[]` if no users exist.
    """
    return list(users_db.values())


@app.get(
    "/users/{user_id}",
    response_model=User,
    status_code=status.HTTP_200_OK,
    summary="Get a user by ID",
)
def get_user(user_id: UUID):
    """
    Retrieve a single user by their UUID.  
    Raises 404 if the user does not exist.
    """
    user = users_db.get(user_id)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with id {user_id} not found.",
        )
    return user


@app.put(
    "/users/{user_id}",
    response_model=User,
    status_code=status.HTTP_200_OK,
    summary="Update an existing user",
)
def update_user(user_id: UUID, payload: UserCreate):
    """
    Update fields of an existing user (name, email, age).  
    - If the user does not exist, returns 404.  
    - Validates the same rules as create (EmailStr, age > 0).  
    """
    existing = users_db.get(user_id)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with id {user_id} not found; cannot update.",
        )

    updated_user = User(id=user_id, **payload.dict())
    users_db[user_id] = updated_user
    return updated_user


@app.delete(
    "/users/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a user",
)
def delete_user(user_id: UUID):
    """
    Delete a user by UUID.  
    - Returns 204 No Content on success.  
    - Raises 404 if the user does not exist.
    """
    if user_id not in users_db:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with id {user_id} not found; cannot delete.",
        )

    del users_db[user_id]
    return None  # 204 No Content


# -------------- Error handlers for bad input --------------

@app.exception_handler(ValueError)
def value_error_handler(request, exc: ValueError):
    """
    Catch any ValueError (e.g. invalid UUID in path) and return 400.
    """
    return HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=str(exc),
    )
