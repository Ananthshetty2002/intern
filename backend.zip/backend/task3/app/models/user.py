# app/models/user.py

fake_users_db = {}
